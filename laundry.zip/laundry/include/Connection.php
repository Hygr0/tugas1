<?php 

$db=new mysqli("localhost","root","","db_laundry");
    if($db->connect_error>0){
		die('Connection error');
	}else
	{
		echo'';
	} ;
?>