
  
        <script type="text/javascript">
        $(document).ready(function() {
                    $.dreamAlert({
                        'type'      :   'success',
                        'message'   :   'Menu Add Successful!',
                        'position'  :   'right'
                    });
                });
                
    </script>
       
       
