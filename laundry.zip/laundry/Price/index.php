
<link href="css/Price-style.css" rel="stylesheet" type="text/css" media="all" />

<!-- <script src="js/jquery.magnific-popup.js" type="text/javascript"></script> -->
	<!-- <script>
		$(document).ready(function() {
			$('.popup-with-zoom-anim').magnificPopup({
				type: 'inline',
				fixedContentPos: false,
				fixedBgPos: true,
				overflowY: 'auto',
				closeBtnInside: true,
				preloader: false,
				midClick: true,
				removalDelay: 300,
				mainClass: 'my-mfp-zoom-in'
			});
		});
	</script>
 -->


<div class="main">
	<div class="padding-w3l">
		<div class="content">
			<div class="grid1">
				<div class="header">
					<h3>Men,s</h3>
				</div>
				<div class="info-agile">
					<p> Free Pick_up</p>
					<p> Total Clothes</p>
					<p class="text"><span>	24/7</span> Support</p>
					<p> Free Delivery</p>
				</div>
				<div class="submit">
					<a class=" sign-up popup-with-zoom-anim"  data-toggle="modal" data-target="#myModal1">Order</a>
				</div>
			</div>
			
			
			<div class="grid2">
				<div class="header">
					<h3>Woman</h3>
				</div>
				<div class="info-agile">
					<p> Free Pick_up</p>
					<p> Total Clothes</p>
					<p class="text"><span>	24/7</span> Support</p>
					<p> Free Delivery</p>
	            </div>
				<div class="submit">
					<a class=" sign-up popup-with-zoom-anim"  data-toggle="modal" data-target="#myModal1">Order</a>
				</div>
			</div>
			
			<div class="grid3">
				<div class="header">
					<h3>Children</h3>
				</div>
				<div class="info-agile">
					<p> Free Pick_up</p>
					<p> Total Clothes</p>
					<p class="text"><span>	24/7</span> Support</p>
					<p> Free Delivery</p>
				</div>
				<div class="submit">
					<a class=" sign-up popup-with-zoom-anim"  data-toggle="modal" data-target="#myModal1">Order</a>
				</div>
			</div>

			
		
		  <div class="clear"> </div>
		</div>
		
		

		
	</div>
</div>
