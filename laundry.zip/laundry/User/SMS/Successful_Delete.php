
       
    <script type="text/javascript">
        $(document).ready(function() {
                    $.dreamAlert({
                        'type'      :   'success',
                        'message'   :   'Tender Delete Successful!',
                        'position'  :   'right',
                        'summary'   :   'this is some text,maybe the user will need.'
                    });
                });
                
    </script>
       
