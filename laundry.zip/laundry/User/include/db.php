<?php 
$db=new MYSQLi("Localhost","root","","db_laundry");
    if($db->connect_error>0){
		die('Connection error');
	}else
	{
		echo'';
	} ;
?>